package com.sscscience.studyplanner.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "student_profile")
data class StudentProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val targetYear: String,
    val gpaGoal: String,
    val dailyGoalHours: Int,
    val boardName: String
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey val id: String,
    val subjectId: String,
    val title: String,
    val isCompleted: Boolean,
    val revisionCount: Int,
    val notes: String?
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: String,
    val durationMinutes: Int,
    val timestamp: Long,
    val dateString: String
)

@Dao
interface PlannerDao {
    @Query("SELECT * FROM student_profile WHERE id = 1")
    fun getProfile(): Flow<StudentProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: StudentProfileEntity)

    @Query("SELECT * FROM chapters WHERE subjectId = :subjectId")
    fun getChapters(subjectId: String): Flow<List<ChapterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySessionEntity)
}

@Database(entities = [StudentProfileEntity::class, ChapterEntity::class, StudySessionEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun plannerDao(): PlannerDao
}