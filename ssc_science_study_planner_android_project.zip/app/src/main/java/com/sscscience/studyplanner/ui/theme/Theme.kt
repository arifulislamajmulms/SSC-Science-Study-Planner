package com.sscscience.studyplanner.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1565C0)
val BlueDark = Color(0xFF0D47A1)
val BlueLight = Color(0xFFE3F2FD)
val SurfaceBg = Color(0xFFF4F7FC)

private val LightColorScheme = lightColorScheme(
    primary = BluePrimary,
    onPrimary = Color.White,
    primaryContainer = BlueLight,
    onPrimaryContainer = BlueDark,
    background = SurfaceBg,
    surface = Color.White
)

@Composable
fun SSCPlannerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}