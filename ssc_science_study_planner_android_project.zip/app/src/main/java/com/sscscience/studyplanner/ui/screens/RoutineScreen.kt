package com.sscscience.studyplanner.ui.screens
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
@Composable fun RoutineScreen() { Text("Daily Routine Timetable") }