package com.sscscience.studyplanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.sscscience.studyplanner.ui.theme.SSCPlannerTheme
import com.sscscience.studyplanner.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SSCPlannerTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route ?: "home"

                Scaffold { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("home") { HomeScreen(onNavigate = { navController.navigate(it) }) }
                        composable("subjects") { SubjectsScreen() }
                        composable("routine") { RoutineScreen() }
                        composable("timer") { TimerScreen() }
                        composable("progress") { ProgressScreen() }
                    }
                }
            }
        }
    }
}